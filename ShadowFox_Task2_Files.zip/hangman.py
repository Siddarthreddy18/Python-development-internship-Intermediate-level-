# hangman.py
# (Code from previous response)
