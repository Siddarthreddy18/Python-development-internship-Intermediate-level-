# web_scraper.py
# (Code from previous response)
